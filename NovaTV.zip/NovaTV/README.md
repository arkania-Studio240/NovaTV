# Nova TV — reproductor IPTV para Android y Android TV

Kotlin · Jetpack Compose · Media3 ExoPlayer · Room · DataStore · Coroutines/Flow · WorkManager · Coil.
Reproduce **solo las listas M3U / M3U Plus que tú añades y tienes autorización para usar**. No incluye canales ni listas.

## Compilar con GitHub Actions (recomendado si usas Code On the Go)
Sube la carpeta `NovaTV` a un repositorio (rama `main`). El workflow `.github/workflows/build.yml` compila con Gradle 8.9 y publica el APK como artefacto «NovaTV-debug-apk» (pestaña Actions > ejecución > Artifacts). También se puede lanzar a mano con «Run workflow».

Versiones: AGP 8.7.3, Kotlin 2.0.21 (plugin de Compose), KSP 2.0.21-1.0.28, Compose BOM 2024.06.00, Media3 1.4.1, Room 2.6.1. Descargan sus dependencias de Google/Maven Central, por eso **no funcionan en el repositorio Maven offline de Code On the Go**.

## Compilar el APK en Android Studio
Requisitos: Android Studio Koala o superior (JDK 17 incluido) y Android SDK 34.

1. Abre la carpeta `NovaTV` con Android Studio y espera al *Gradle Sync* (genera el wrapper por su cuenta; usa Gradle 8.9).
2. Menú **Build > Build Bundle(s) / APK(s) > Build APK(s)**, o en terminal (con wrapper ya generado):
   - Depuración: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
   - Release (firmado con la clave de depuración, instalable): `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`
3. Pruebas unitarias del parser: `./gradlew testDebugUnitTest`.

Para publicar en una tienda crea tu propio keystore y cambia `signingConfig` en `app/build.gradle.kts`.

## Instalar
**Teléfono / tablet:** copia el APK, ábrelo y permite «instalar apps desconocidas», o `adb install -r app-debug.apk`.

**Android TV / Google TV:**
- `adb connect IP_DE_LA_TV:5555` (activa antes *Depuración por red* en Opciones de desarrollador) y luego `adb install -r app-debug.apk`; o
- copia el APK a un USB / usa una app como «Send Files to TV» o «Downloader» y ábrelo en la TV.
La app aparece en el launcher de TV con su banner.

## Manejo con mando (D-pad)
- Flechas: moverse por filas y columnas; el control con foco muestra un borde azul.
- Enter/OK: seleccionar. Atrás: cerrar controles → salir del reproductor.
- En el reproductor (controles ocultos): ↑ canal anterior, ↓ siguiente (también teclas CH+/CH−), ← → volumen, OK muestra los controles (pista de audio/subtítulos, favoritos, pausa).

## Seguridad y privacidad
- La URL (o la URI del archivo) de cada lista se guarda **cifrada con AES-GCM** (clave en Android Keystore) y se muestra enmascarada al editar.
- Los registros nunca imprimen URLs (`LogSanitizer`). No hay analíticas ni servidores propios; `allowBackup` está desactivado.
- Ajustes > «Borrar listas, credenciales y datos» elimina listas, canales, favoritos, historial y la clave de cifrado.

## Limitaciones conocidas
- Las URLs de los canales (que a veces incluyen credenciales) se guardan en la base de datos privada de la app **sin cifrar**, por rendimiento con listas grandes; solo la app puede leerla.
- Se permite tráfico `http` (muchos streams IPTV no usan HTTPS). Cámbialo en el manifiesto si solo usas HTTPS.
- Que un canal funcione depende del servidor y del formato del stream; la app no elude restricciones de acceso. Soporta HLS, DASH y flujos progresivos/TS; no incluye RTSP/UDP.
- La interfaz está en español (sin traducciones adicionales). Importar archivo requiere un selector de archivos del sistema, que algunas TV no traen: usa entonces la URL.
- Este proyecto se generó sin poder compilarlo en el entorno de creación: la primera compilación en Android Studio puede mostrar pequeños ajustes (versiones o imports).
