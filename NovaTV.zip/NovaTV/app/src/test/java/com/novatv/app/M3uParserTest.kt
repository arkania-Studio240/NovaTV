package com.novatv.app

import com.novatv.app.data.m3u.M3uParser
import com.novatv.app.security.LogSanitizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Test
import java.io.BufferedReader
import java.io.StringReader

class M3uParserTest {
    private fun parse(text: String) = M3uParser.parse(BufferedReader(StringReader(text))).toList()

    @Test
    fun parsesM3uPlusAttributes() {
        val list = parse(
            """
            #EXTM3U
            #EXTINF:-1 tvg-id="la1.es" tvg-name="La 1 HD" tvg-logo="http://x/logo.png" group-title="Noticias, España",La 1
            http://host/live/1.m3u8
            """.trimIndent()
        )
        assertEquals(1, list.size)
        val c = list[0]
        assertEquals("La 1", c.name)
        assertEquals("la1.es", c.tvgId)
        assertEquals("http://x/logo.png", c.logo)
        assertEquals("Noticias, España", c.group)
        assertEquals("http://host/live/1.m3u8", c.url)
    }

    @Test
    fun usesExtGrpAndDefaultGroup() {
        val list = parse(
            "#EXTM3U\n#EXTINF:-1,Uno\n#EXTGRP:Música\nhttps://a/1\n#EXTINF:-1,Dos\nhttps://a/2\n"
        )
        assertEquals("Música", list[0].group)
        assertEquals(M3uParser.DEFAULT_GROUP, list[1].group)
    }

    @Test
    fun fallsBackToTvgNameAndHandlesQuotesInTitle() {
        val list = parse("#EXTINF:-1 tvg-name=\"Solo nombre\",\nhttp://a/1\n#EXTINF:-1 tvg-id=\"x\",Canal \"HD\"\nhttp://a/2")
        assertEquals("Solo nombre", list[0].name)
        assertEquals("Canal \"HD\"", list[1].name)
    }

    @Test
    fun handlesBomBlankLinesAndPlainUrls() {
        val list = parse("\uFEFF#EXTM3U\n\n#EXTVLCOPT:foo=bar\n\nhttp://a/stream/canal.ts\n")
        assertEquals(1, list.size)
        assertEquals("canal.ts", list[0].name)
        assertNull(list[0].tvgId)
    }

    @Test
    fun emptyAndInvalidListsYieldNothing() {
        assertEquals(0, parse("").size)
        assertEquals(0, parse("esto no es una lista\nnada de nada").size)
    }

    @Test
    fun redactHidesCredentials() {
        val out = LogSanitizer.redact("http://user:secret@host.tv:8080/get.php?username=a&password=b")
        assertFalse(out.contains("secret"))
        assertFalse(out.contains("password"))
        assertEquals("http://host.tv/…", out)
    }
}
