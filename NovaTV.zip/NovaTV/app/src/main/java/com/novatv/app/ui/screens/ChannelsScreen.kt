package com.novatv.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.novatv.app.data.db.ChannelItem
import com.novatv.app.ui.MainViewModel
import com.novatv.app.ui.components.ChannelRow
import com.novatv.app.ui.components.EmptyState
import com.novatv.app.ui.components.ImportBanner
import com.novatv.app.ui.components.focusBorder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChannelsScreen(
    vm: MainViewModel,
    isTv: Boolean,
    onPlay: (ChannelItem, List<ChannelItem>) -> Unit,
    onLists: () -> Unit,
    modifier: Modifier = Modifier
) {
    val channels by vm.channels.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val total by vm.totalChannels.collectAsStateWithLifecycle()
    val importState by vm.importState.collectAsStateWithLifecycle()
    val gridState = rememberLazyGridState()

    val nearEnd by remember {
        derivedStateOf {
            val last = gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= gridState.layoutInfo.totalItemsCount - 12
        }
    }
    LaunchedEffect(nearEnd, channels.size) {
        if (nearEnd && channels.isNotEmpty() && channels.size >= filter.limit) vm.loadMore()
    }

    Column(modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
        OutlinedTextField(
            value = filter.query,
            onValueChange = vm::setQuery,
            modifier = Modifier.fillMaxWidth().focusBorder(),
            singleLine = true,
            placeholder = { Text("Buscar canal") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (filter.query.isNotEmpty()) {
                    IconButton(onClick = { vm.setQuery("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Borrar búsqueda")
                    }
                }
            }
        )
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilterChip(
                    selected = filter.favOnly, onClick = vm::toggleFavOnly,
                    label = { Text("Favoritos") }, modifier = Modifier.focusBorder()
                )
            }
            item {
                FilterChip(
                    selected = filter.alpha, onClick = vm::toggleAlpha,
                    label = { Text("A–Z") }, modifier = Modifier.focusBorder()
                )
            }
            item {
                FilterChip(
                    selected = filter.category == null, onClick = { vm.setCategory(null) },
                    label = { Text("Todos") }, modifier = Modifier.focusBorder()
                )
            }
            items(categories.take(80), key = { (if (it.thematic) "t:" else "g:") + it.label }) { c ->
                FilterChip(
                    selected = filter.category == c, onClick = { vm.setCategory(c) },
                    label = { Text(c.label, maxLines = 1) }, modifier = Modifier.focusBorder()
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        ImportBanner(importState, vm::cancelImport, vm::dismissImport)
        Spacer(Modifier.height(8.dp))

        when {
            total == 0 -> EmptyState(
                "Aún no hay canales",
                "Añade o actualiza una lista M3U para ver canales.",
                "Ir a listas", onLists
            )
            channels.isEmpty() -> EmptyState(
                "Sin resultados",
                if (filter.favOnly) "Todavía no marcaste favoritos en este filtro."
                else "Ningún canal coincide con la búsqueda o la categoría."
            )
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(300.dp),
                state = gridState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(channels, key = { it.channel.id }) { item ->
                    ChannelRow(
                        item = item,
                        onClick = { onPlay(item, channels) },
                        onFavorite = { vm.toggleFavorite(item) }
                    )
                }
            }
        }
    }
}
