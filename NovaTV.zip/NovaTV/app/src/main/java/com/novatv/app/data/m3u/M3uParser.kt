package com.novatv.app.data.m3u

import java.io.BufferedReader

data class ParsedChannel(
    val name: String,
    val tvgId: String?,
    val logo: String?,
    val group: String,
    val url: String
)

/**
 * Parser M3U / M3U Plus en streaming: lee línea a línea y emite canales de uno en uno,
 * así que no necesita cargar la lista completa en memoria.
 */
object M3uParser {
    const val DEFAULT_GROUP = "Sin categoría"

    private val ATTR = Regex("""([A-Za-z0-9_-]+)="([^"]*)"""")
    private val URL_RE = Regex("^[A-Za-z][A-Za-z0-9+.-]*://\\S.*")

    private data class Info(val name: String, val tvgId: String?, val logo: String?, val group: String?)

    fun parse(reader: BufferedReader): Sequence<ParsedChannel> = sequence {
        var info: Info? = null
        var extGroup: String? = null
        var first = true
        while (true) {
            var line = reader.readLine() ?: break
            if (first) {
                line = line.removePrefix("\uFEFF")
                first = false
            }
            line = line.trim()
            if (line.isEmpty()) continue
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> info = parseInfo(line)
                line.startsWith("#EXTGRP:", ignoreCase = true) -> extGroup = line.substringAfter(':').trim()
                line.startsWith("#") -> Unit
                URL_RE.matches(line) -> {
                    val i = info
                    val group = i?.group?.takeIf { it.isNotBlank() }
                        ?: extGroup?.takeIf { it.isNotBlank() }
                        ?: DEFAULT_GROUP
                    val name = i?.name?.takeIf { it.isNotBlank() }
                        ?: line.substringAfterLast('/').substringBefore('?').ifBlank { "Canal sin nombre" }
                    yield(ParsedChannel(name, i?.tvgId, i?.logo, group, line))
                    info = null
                    extGroup = null
                }
                else -> Unit
            }
        }
    }

    private fun parseInfo(line: String): Info {
        val matches = ATTR.findAll(line).toList()
        val attrs = matches.associate { it.groupValues[1].lowercase() to it.groupValues[2] }
        val searchFrom = matches.lastOrNull()?.range?.last?.plus(1) ?: 0
        val comma = line.indexOf(',', searchFrom)
        val title = if (comma >= 0) line.substring(comma + 1).trim() else ""
        val name = title.ifBlank { attrs["tvg-name"].orEmpty() }.ifBlank { "Canal sin nombre" }
        return Info(
            name = name,
            tvgId = attrs["tvg-id"]?.takeIf { it.isNotBlank() },
            logo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() },
            group = attrs["group-title"]?.trim()
        )
    }
}
