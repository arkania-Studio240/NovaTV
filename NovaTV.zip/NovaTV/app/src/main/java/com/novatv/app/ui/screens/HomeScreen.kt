@file:OptIn(ExperimentalLayoutApi::class)

package com.novatv.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.novatv.app.data.db.ChannelItem
import com.novatv.app.ui.Category
import com.novatv.app.ui.MainViewModel
import com.novatv.app.ui.components.ChannelLogo
import com.novatv.app.ui.components.ChannelTile
import com.novatv.app.ui.components.EmptyState
import com.novatv.app.ui.components.ImportBanner
import com.novatv.app.ui.components.SectionTitle
import com.novatv.app.ui.components.focusBorder

@Composable
fun HomeScreen(
    vm: MainViewModel,
    onWatch: () -> Unit,
    onPlay: (ChannelItem, List<ChannelItem>) -> Unit,
    onOpenCategory: (Category) -> Unit,
    onLists: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val recents by vm.recents.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val total by vm.totalChannels.collectAsStateWithLifecycle()
    val importState by vm.importState.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(24.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Nova TV", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Tus listas M3U, en cualquier pantalla",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onWatch, modifier = Modifier.focusBorder()) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Ver TV")
                }
                OutlinedButton(onClick = onLists, modifier = Modifier.focusBorder()) { Text("Listas") }
                OutlinedButton(onClick = onSettings, modifier = Modifier.focusBorder()) {
                    Icon(Icons.Default.Settings, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Ajustes")
                }
            }
        }
        item { ImportBanner(importState, vm::cancelImport, vm::dismissImport) }

        if (playlists.isEmpty()) {
            item {
                EmptyState(
                    "Todavía no tienes listas",
                    "Añade una lista M3U o M3U Plus que tengas autorización para usar.",
                    "Añadir lista", onLists
                )
            }
        } else if (total == 0) {
            item {
                EmptyState(
                    "Sin canales",
                    "Tus listas no tienen canales cargados. Actualízalas desde la pantalla de listas.",
                    "Ir a listas", onLists
                )
            }
        }

        recents.firstOrNull()?.let { last ->
            item {
                Column {
                SectionTitle("Continuar viendo")
                Spacer(Modifier.size(8.dp))
                Card(
                    onClick = { onPlay(last, recents) },
                    modifier = Modifier.fillMaxWidth().focusBorder(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        ChannelLogo(last.channel.name, last.channel.logo, Modifier.size(72.dp))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(last.channel.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(last.channel.groupTitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                        Icon(Icons.Default.PlayArrow, contentDescription = "Reproducir", tint = MaterialTheme.colorScheme.primary)
                    }
                }
                }
            }
        }

        if (favorites.isNotEmpty()) {
            item { ChannelRowSection("Canales favoritos", favorites, onPlay) }
        }
        if (recents.size > 1) {
            item { ChannelRowSection("Canales recientes", recents.drop(1), onPlay) }
        }
        if (categories.isNotEmpty()) {
            item {
                Column {
                SectionTitle("Categorías")
                Spacer(Modifier.size(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(categories.take(60), key = { (if (it.thematic) "t:" else "g:") + it.label }) { c ->
                        Card(
                            onClick = { onOpenCategory(c) },
                            modifier = Modifier.focusBorder(),
                            colors = CardDefaults.cardColors(
                                containerColor = if (c.thematic) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
                                else MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Text(
                                c.label, Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                                maxLines = 1, fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
                }
            }
        }
    }
}

@Composable
private fun ChannelRowSection(title: String, list: List<ChannelItem>, onPlay: (ChannelItem, List<ChannelItem>) -> Unit) {
    Column {
        SectionTitle(title)
        Spacer(Modifier.size(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(list, key = { it.channel.channelKey }) { item ->
                ChannelTile(item, onClick = { onPlay(item, list) })
            }
        }
    }
}
