package com.novatv.app.data.db

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

const val TYPE_URL = "url"
const val TYPE_FILE = "file"

/** encSource: URL o URI del archivo, cifrado con AES-GCM (Android Keystore). */
@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sourceType: String,
    val encSource: String,
    val etag: String? = null,
    val lastUpdated: Long = 0,
    val channelCount: Int = 0
)

@Entity(
    tableName = "channels",
    foreignKeys = [ForeignKey(
        entity = PlaylistEntity::class,
        parentColumns = ["id"],
        childColumns = ["playlistId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("channelKey"), Index(value = ["playlistId", "active"]), Index("groupTitle")]
)
data class ChannelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    /** Clave estable (lista + hash de URL) para conservar favoritos al actualizar. */
    val channelKey: String,
    val name: String,
    val tvgId: String?,
    val logo: String?,
    val groupTitle: String,
    val url: String,
    /** false mientras se importa; se activa de forma atómica al terminar. */
    val active: Boolean = false
)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val channelKey: String, val addedAt: Long)

@Entity(tableName = "history")
data class HistoryEntity(@PrimaryKey val channelKey: String, val lastPlayedAt: Long)

data class ChannelItem(
    @Embedded val channel: ChannelEntity,
    val isFavorite: Boolean
)
