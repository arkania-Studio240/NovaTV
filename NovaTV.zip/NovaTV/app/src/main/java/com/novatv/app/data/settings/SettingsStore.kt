package com.novatv.app.data.settings

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class AppSettings(
    val autoUpdate: Boolean = false,
    val resumeLast: Boolean = true,
    val playOnStart: Boolean = false,
    val theme: String = "dark",
    val lastChannelKey: String? = null
)

private val Context.dataStore by preferencesDataStore(name = "nova_settings")

class SettingsStore(private val ctx: Context) {
    private object K {
        val AUTO = booleanPreferencesKey("auto_update")
        val RESUME = booleanPreferencesKey("resume_last")
        val PLAY_START = booleanPreferencesKey("play_on_start")
        val THEME = stringPreferencesKey("theme")
        val LAST = stringPreferencesKey("last_channel")
    }

    val flow: Flow<AppSettings> = ctx.dataStore.data.map { p ->
        AppSettings(
            autoUpdate = p[K.AUTO] ?: false,
            resumeLast = p[K.RESUME] ?: true,
            playOnStart = p[K.PLAY_START] ?: false,
            theme = p[K.THEME] ?: "dark",
            lastChannelKey = p[K.LAST]
        )
    }

    private suspend fun <T> put(key: Preferences.Key<T>, value: T) {
        ctx.dataStore.edit { it[key] = value }
    }

    suspend fun setAutoUpdate(v: Boolean) = put(K.AUTO, v)
    suspend fun setResumeLast(v: Boolean) = put(K.RESUME, v)
    suspend fun setPlayOnStart(v: Boolean) = put(K.PLAY_START, v)
    suspend fun setTheme(v: String) = put(K.THEME, v)
    suspend fun setLast(key: String?) {
        ctx.dataStore.edit { if (key == null) it.remove(K.LAST) else it[K.LAST] = key }
    }
}
