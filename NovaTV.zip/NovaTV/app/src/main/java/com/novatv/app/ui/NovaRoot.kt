package com.novatv.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.novatv.app.ui.components.focusBorder
import com.novatv.app.ui.screens.ChannelsScreen
import com.novatv.app.ui.screens.HomeScreen
import com.novatv.app.ui.screens.PlayerScreen
import com.novatv.app.ui.screens.PlaylistsScreen
import com.novatv.app.ui.screens.SettingsScreen
import kotlinx.coroutines.launch

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("home", "Inicio", Icons.Default.Home),
    Tab("channels", "Canales", Icons.Default.List),
    Tab("lists", "Listas", Icons.Default.Menu),
    Tab("settings", "Ajustes", Icons.Default.Settings)
)

@Composable
fun NovaRoot(vm: MainViewModel, isTv: Boolean, firstLaunch: Boolean) {
    val nav = rememberNavController()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val scope = rememberCoroutineScope()
    var autoStartPending by rememberSaveable { mutableStateOf(firstLaunch) }

    fun goTab(r: String) = nav.navigate(r) {
        popUpTo("home") { saveState = true }
        launchSingleTop = true
        restoreState = true
    }

    fun play() = nav.navigate("player") { launchSingleTop = true }

    // «Reproducir al iniciar»: solo en el primer arranque y si el usuario lo activó.
    LaunchedEffect(Unit) {
        if (autoStartPending) {
            autoStartPending = false
            val s = vm.readSettings()
            val key = if (s.playOnStart) vm.lastPlayableKey() else null
            if (key != null) {
                vm.openByKey(key)
                play()
            }
        }
    }

    val watch: () -> Unit = {
        scope.launch {
            val key = if (vm.settings.value.resumeLast) vm.lastPlayableKey() else null
            if (key != null) {
                vm.openByKey(key)
                play()
            } else goTab("channels")
        }
    }

    val showNav = route != "player"
    val wide = isTv || LocalConfiguration.current.screenWidthDp >= 600

    val host: @Composable (Modifier) -> Unit = { m ->
        NavHost(nav, startDestination = "home", modifier = m) {
            composable("home") {
                HomeScreen(
                    vm = vm,
                    onWatch = watch,
                    onPlay = { item, list -> vm.openChannel(item, list); play() },
                    onOpenCategory = { c -> vm.setCategory(c); goTab("channels") },
                    onLists = { goTab("lists") },
                    onSettings = { goTab("settings") },
                    modifier = Modifier.fillMaxSize()
                )
            }
            composable("channels") {
                ChannelsScreen(
                    vm = vm, isTv = isTv,
                    onPlay = { item, list -> vm.openChannel(item, list); play() },
                    onLists = { goTab("lists") },
                    modifier = Modifier.fillMaxSize()
                )
            }
            composable("lists") { PlaylistsScreen(vm, Modifier.fillMaxSize()) }
            composable("settings") { SettingsScreen(vm, onManageLists = { goTab("lists") }, modifier = Modifier.fillMaxSize()) }
            composable("player") { PlayerScreen(vm, isTv) { nav.popBackStack() } }
        }
    }

    if (showNav && wide) {
        Row(Modifier.fillMaxSize()) {
            NavigationRail(Modifier.fillMaxHeight()) {
                Spacer(Modifier.height(12.dp))
                TABS.forEach { t ->
                    NavigationRailItem(
                        selected = route == t.route,
                        onClick = { goTab(t.route) },
                        icon = { Icon(t.icon, contentDescription = null) },
                        label = { Text(t.label) },
                        modifier = Modifier.focusBorder(RoundedCornerShape(16.dp))
                    )
                }
            }
            host(Modifier.weight(1f).fillMaxHeight())
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            host(Modifier.weight(1f).fillMaxWidth())
            if (showNav) {
                NavigationBar {
                    TABS.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = { goTab(t.route) },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        }
    }
}
