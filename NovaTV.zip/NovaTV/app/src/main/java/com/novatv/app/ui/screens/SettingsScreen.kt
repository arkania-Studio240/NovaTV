package com.novatv.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.novatv.app.ui.MainViewModel
import com.novatv.app.ui.components.SectionTitle
import com.novatv.app.ui.components.focusBorder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onManageLists: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }
    var confirmWipe by remember { mutableStateOf(false) }
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?"
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { SectionTitle("Ajustes") }
        item {
            OutlinedButton(onClick = onManageLists, modifier = Modifier.fillMaxWidth().focusBorder()) {
                Text("Administrar listas")
            }
        }
        item {
            SwitchRow(
                "Actualización automática",
                "Actualiza las listas por URL cada 24 h con conexión. Si la lista no cambió, no se vuelve a descargar.",
                s.autoUpdate, vm::setAutoUpdate
            )
        }
        item {
            SwitchRow(
                "Reproducir el último canal",
                "El botón «Ver TV» abre directamente el último canal visto.",
                s.resumeLast, vm::setResumeLast
            )
        }
        item {
            SwitchRow(
                "Reproducir al iniciar",
                "Al abrir la aplicación empieza a reproducir el último canal. Desactivado por defecto.",
                s.playOnStart, vm::setPlayOnStart
            )
        }
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tema visual", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("dark" to "Azul oscuro", "black" to "Negro", "light" to "Claro").forEach { (k, label) ->
                            FilterChip(
                                selected = s.theme == k, onClick = { vm.setTheme(k) },
                                label = { Text(label) }, modifier = Modifier.focusBorder()
                            )
                        }
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth().focusBorder()) {
                Text("Limpiar historial")
            }
        }
        item {
            OutlinedButton(onClick = { confirmWipe = true }, modifier = Modifier.fillMaxWidth().focusBorder()) {
                Text("Borrar listas, credenciales y datos")
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Información de la aplicación", fontWeight = FontWeight.SemiBold)
                    Text("Nova TV · versión $version", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Reproduce solo las listas que tú añades. Sin analíticas ni envío de datos a terceros; " +
                            "las direcciones de las listas se guardan cifradas en este dispositivo.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Limpiar historial") },
            text = { Text("Se borrarán «Continuar viendo», los recientes y el último canal recordado. Los favoritos se conservan.") },
            confirmButton = {
                TextButton(onClick = { confirmClear = false; vm.clearHistory() }, modifier = Modifier.focusBorder()) { Text("Limpiar") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }, modifier = Modifier.focusBorder()) { Text("Cancelar") } }
        )
    }
    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("Borrar todo") },
            text = { Text("Se eliminarán todas las listas, sus direcciones guardadas, los favoritos y el historial. No se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = { confirmWipe = false; vm.deleteEverything() }, modifier = Modifier.focusBorder()) { Text("Borrar todo") }
            },
            dismissButton = { TextButton(onClick = { confirmWipe = false }, modifier = Modifier.focusBorder()) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card(
        onClick = { onChange(!checked) },
        modifier = Modifier.fillMaxWidth().focusBorder(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = null)
        }
    }
}
