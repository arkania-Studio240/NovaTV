package com.novatv.app.ui.screens

import android.content.ActivityNotFoundException
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.material3.ExperimentalMaterial3Api
import android.widget.Toast
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.novatv.app.data.db.PlaylistEntity
import com.novatv.app.data.db.TYPE_URL
import com.novatv.app.ui.MainViewModel
import com.novatv.app.ui.components.EmptyState
import com.novatv.app.ui.components.ImportBanner
import com.novatv.app.ui.components.SectionTitle
import com.novatv.app.ui.components.focusBorder
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistsScreen(vm: MainViewModel, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val importState by vm.importState.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<PlaylistEntity?>(null) }
    var deleting by remember { mutableStateOf<PlaylistEntity?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFile(uri)
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { SectionTitle("Listas M3U") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { showAdd = true }, modifier = Modifier.focusBorder()) { Text("Añadir URL") }
                OutlinedButton(
                    onClick = {
                        try {
                            picker.launch(arrayOf("*/*"))
                        } catch (e: ActivityNotFoundException) {
                            Toast.makeText(ctx, "Este dispositivo no tiene selector de archivos. Usa una URL.", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.focusBorder()
                ) { Text("Importar archivo") }
            }
        }
        item { ImportBanner(importState, vm::cancelImport, vm::dismissImport) }
        if (playlists.isEmpty()) {
            item {
                EmptyState(
                    "Sin listas",
                    "Añade una URL M3U o importa un archivo .m3u / .m3u8. Las direcciones se guardan cifradas y nunca se muestran en pantalla."
                )
            }
        }
        items(playlists, key = { it.id }) { p ->
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "${if (p.sourceType == TYPE_URL) "Lista por URL" else "Archivo local"} · ${p.channelCount} canales · " +
                            if (p.lastUpdated == 0L) "sin actualizar"
                            else "actualizada ${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(p.lastUpdated))}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { vm.refresh(p) }, modifier = Modifier.focusBorder()) { Text("Actualizar") }
                        TextButton(onClick = { editing = p }, modifier = Modifier.focusBorder()) { Text("Editar") }
                        TextButton(onClick = { deleting = p }, modifier = Modifier.focusBorder()) { Text("Eliminar") }
                    }
                }
            }
        }
    }

    if (showAdd) {
        PlaylistDialog(
            title = "Añadir lista por URL", initialName = "", askUrl = true, urlOptional = false,
            onDismiss = { showAdd = false },
            onConfirm = { name, url -> showAdd = false; vm.addUrl(name, url.orEmpty()) }
        )
    }
    editing?.let { p ->
        PlaylistDialog(
            title = "Editar lista", initialName = p.name, askUrl = p.sourceType == TYPE_URL, urlOptional = true,
            onDismiss = { editing = null },
            onConfirm = { name, url -> editing = null; vm.updatePlaylist(p, name, url) }
        )
    }
    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Eliminar lista") },
            text = { Text("Se borrarán «${p.name}», sus canales y su dirección guardada.") },
            confirmButton = {
                TextButton(onClick = { deleting = null; vm.deletePlaylist(p) }, modifier = Modifier.focusBorder()) { Text("Eliminar") }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }, modifier = Modifier.focusBorder()) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun PlaylistDialog(
    title: String,
    initialName: String,
    askUrl: Boolean,
    urlOptional: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (name: String, url: String?) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var url by remember { mutableStateOf("") }
    var reveal by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    label = { Text("Nombre") },
                    modifier = Modifier.fillMaxWidth().focusRequester(focus)
                )
                if (askUrl) {
                    OutlinedTextField(
                        value = url, onValueChange = { url = it }, singleLine = true,
                        label = { Text(if (urlOptional) "Nueva URL (vacío = conservar)" else "URL M3U") },
                        visualTransformation = if (reveal) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    TextButton(onClick = { reveal = !reveal }, modifier = Modifier.focusBorder()) {
                        Text(if (reveal) "Ocultar URL" else "Mostrar URL")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(name, url.ifBlank { null }) },
                enabled = name.isNotBlank() && (urlOptional || !askUrl || url.isNotBlank()),
                modifier = Modifier.focusBorder()
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss, modifier = Modifier.focusBorder()) { Text("Cancelar") } }
    )
}
