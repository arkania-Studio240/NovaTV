package com.novatv.app.data.repo

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import com.novatv.app.data.db.ChannelEntity
import com.novatv.app.data.db.NovaDatabase
import com.novatv.app.data.db.PlaylistEntity
import com.novatv.app.data.db.TYPE_FILE
import com.novatv.app.data.db.TYPE_URL
import com.novatv.app.data.m3u.M3uParser
import com.novatv.app.security.CryptoBox
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

class ImportException(message: String) : Exception(message)

data class ImportProgress(val name: String, val channels: Int, val fraction: Float?)
data class RefreshResult(val count: Int, val unchanged: Boolean)

private class CountingInputStream(input: InputStream) : FilterInputStream(input) {
    var count = 0L
        private set

    override fun read(): Int = super.read().also { if (it >= 0) count++ }
    override fun read(b: ByteArray, off: Int, len: Int): Int =
        super.read(b, off, len).also { if (it > 0) count += it }
}

private class Opened(val stream: InputStream, val length: Long, val etag: String?)

class NovaRepository(private val ctx: Context, db: NovaDatabase) {
    private val plDao = db.playlists()
    private val chDao = db.channels()

    val playlists: Flow<List<PlaylistEntity>> = plDao.observeAll()

    suspend fun addUrl(name: String, url: String): Long = withContext(Dispatchers.IO) {
        plDao.insert(
            PlaylistEntity(
                name = name.trim().ifBlank { "Mi lista" },
                sourceType = TYPE_URL,
                encSource = CryptoBox.encrypt(url.trim())
            )
        )
    }

    suspend fun addFile(uri: Uri): Long = withContext(Dispatchers.IO) {
        runCatching {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val name = displayName(uri)?.substringBeforeLast('.')?.ifBlank { null } ?: "Lista importada"
        plDao.insert(
            PlaylistEntity(name = name, sourceType = TYPE_FILE, encSource = CryptoBox.encrypt(uri.toString()))
        )
    }

    suspend fun updatePlaylist(id: Long, name: String, newUrl: String?) = withContext(Dispatchers.IO) {
        val p = plDao.get(id) ?: return@withContext
        val changedSource = !newUrl.isNullOrBlank()
        plDao.update(
            p.copy(
                name = name.trim().ifBlank { p.name },
                encSource = if (changedSource) CryptoBox.encrypt(newUrl!!.trim()) else p.encSource,
                etag = if (changedSource) null else p.etag
            )
        )
    }

    suspend fun deletePlaylist(id: Long) = withContext(Dispatchers.IO) {
        chDao.deleteFavoritesWithPrefix("$id|")
        chDao.deleteHistoryWithPrefix("$id|")
        plDao.delete(id)
    }

    /** Borra listas, canales, favoritos, historial y la clave de cifrado. */
    suspend fun deleteAll() = withContext(Dispatchers.IO) {
        chDao.clearFavorites()
        chDao.clearHistory()
        plDao.deleteAll()
        CryptoBox.reset()
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) { chDao.clearHistory() }

    /** Actualiza todas las listas por URL. Usa ETag para no volver a descargar si no hay cambios. */
    suspend fun refreshAll() {
        for (p in plDao.getAll()) {
            if (p.sourceType != TYPE_URL) continue
            try {
                refresh(p.id, force = false) { }
            } catch (e: ImportException) {
                // Una lista que falla no impide actualizar las demás.
            }
        }
    }

    suspend fun refresh(id: Long, force: Boolean, onProgress: (ImportProgress) -> Unit): RefreshResult =
        withContext(Dispatchers.IO) {
            val pl = plDao.get(id) ?: throw ImportException("La lista ya no existe.")
            val source = try {
                CryptoBox.decrypt(pl.encSource)
            } catch (e: Exception) {
                throw ImportException("No se pudo leer la dirección guardada. Edita la lista y vuelve a introducirla.")
            }
            onProgress(ImportProgress(pl.name, 0, null))
            chDao.deleteInactive(id)

            var opened: Opened? = null
            try {
                opened = if (pl.sourceType == TYPE_URL) openUrl(source, if (force) null else pl.etag)
                else openFile(Uri.parse(source))
                if (opened == null) return@withContext RefreshResult(pl.channelCount, unchanged = true)

                val counting = CountingInputStream(opened.stream)
                val total = opened.length
                val seen = HashSet<Int>()
                val batch = ArrayList<ChannelEntity>(BATCH)
                var count = 0
                BufferedReader(InputStreamReader(counting, Charsets.UTF_8)).use { reader ->
                    for (c in M3uParser.parse(reader)) {
                        currentCoroutineContext().ensureActive()
                        val hash = c.url.hashCode()
                        if (!seen.add(hash)) continue // duplicados dentro de la misma lista
                        batch += ChannelEntity(
                            playlistId = id,
                            channelKey = "$id|$hash",
                            name = c.name,
                            tvgId = c.tvgId,
                            logo = c.logo,
                            groupTitle = c.group,
                            url = c.url
                        )
                        count++
                        if (batch.size >= BATCH) {
                            chDao.insertAll(batch)
                            batch.clear()
                            val f = if (total > 0) (counting.count.toFloat() / total).coerceIn(0f, 1f) else null
                            onProgress(ImportProgress(pl.name, count, f))
                        }
                    }
                }
                if (batch.isNotEmpty()) chDao.insertAll(batch)
                if (count == 0) throw ImportException("La lista está vacía o no tiene formato M3U válido.")
                chDao.activate(id)
                plDao.updateMeta(id, System.currentTimeMillis(), count, opened.etag)
                RefreshResult(count, unchanged = false)
            } catch (e: Throwable) {
                withContext(NonCancellable) { chDao.deleteInactive(id) }
                if (!currentCoroutineContext().isActive) throw CancellationException("Importación cancelada")
                throw mapError(e)
            } finally {
                runCatching { opened?.stream?.close() }
            }
        }

    private suspend fun openUrl(start: String, etag: String?): Opened? {
        var current = start
        val job = currentCoroutineContext()[Job]
        repeat(MAX_REDIRECTS + 1) {
            val url = URL(current)
            if (url.protocol != "http" && url.protocol != "https") {
                throw ImportException("Solo se admiten direcciones http:// o https://")
            }
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = false
            conn.setRequestProperty("User-Agent", "NovaTV/1.0")
            if (etag != null) conn.setRequestProperty("If-None-Match", etag)
            // Si se cancela la importación, cerrar la conexión desbloquea la lectura.
            job?.invokeOnCompletion { if (it != null) conn.disconnect() }
            val code = conn.responseCode
            when (code) {
                304 -> { conn.disconnect(); return null }
                in 200..299 -> return Opened(conn.inputStream, conn.contentLengthLong, conn.getHeaderField("ETag"))
                301, 302, 303, 307, 308 -> {
                    val loc = conn.getHeaderField("Location")
                    conn.disconnect()
                    if (loc.isNullOrBlank()) throw ImportException("Redirección no válida.")
                    current = URL(URL(current), loc).toString()
                }
                401, 403 -> { conn.disconnect(); throw ImportException("Acceso denegado por el servidor (código $code).") }
                else -> { conn.disconnect(); throw ImportException("El servidor respondió con error $code.") }
            }
        }
        throw ImportException("Demasiadas redirecciones.")
    }

    private fun openFile(uri: Uri): Opened {
        val stream = ctx.contentResolver.openInputStream(uri)
            ?: throw ImportException("No se pudo abrir el archivo.")
        val length = runCatching {
            ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        }.getOrDefault(-1L)
        return Opened(stream, length, null)
    }

    private fun displayName(uri: Uri): String? = runCatching {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) c.getString(i) else null
        }
    }.getOrNull()

    private fun mapError(e: Throwable): Throwable = when (e) {
        is CancellationException -> e
        is ImportException -> e
        is UnknownHostException -> ImportException("Sin conexión o servidor no encontrado.")
        is SocketTimeoutException -> ImportException("Tiempo de espera agotado al conectar.")
        is MalformedURLException -> ImportException("La dirección no es válida.")
        is SecurityException -> ImportException("Sin permiso para leer el archivo. Impórtalo de nuevo.")
        is IOException -> ImportException("Error de red o de lectura (${e.javaClass.simpleName}).")
        else -> ImportException("Error inesperado al procesar la lista.")
    }

    private companion object {
        const val BATCH = 1000
        const val MAX_REDIRECTS = 5
    }
}
