package com.novatv.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE")
    suspend fun getAll(): List<PlaylistEntity>

    @Query("SELECT * FROM playlists WHERE id = :id")
    suspend fun get(id: Long): PlaylistEntity?

    @Insert
    suspend fun insert(p: PlaylistEntity): Long

    @Update
    suspend fun update(p: PlaylistEntity)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM playlists")
    suspend fun deleteAll()

    @Query("UPDATE playlists SET lastUpdated = :time, channelCount = :count, etag = :etag WHERE id = :id")
    suspend fun updateMeta(id: Long, time: Long, count: Int, etag: String?)
}

@Dao
abstract class ChannelDao {
    @Insert
    abstract suspend fun insertAll(list: List<ChannelEntity>)

    @Query("DELETE FROM channels WHERE playlistId = :pid AND active = 1")
    abstract suspend fun deleteActive(pid: Long)

    @Query("UPDATE channels SET active = 1 WHERE playlistId = :pid AND active = 0")
    abstract suspend fun setActive(pid: Long)

    @Query("DELETE FROM channels WHERE playlistId = :pid AND active = 0")
    abstract suspend fun deleteInactive(pid: Long)

    /** Sustituye de golpe los canales viejos por los nuevos. */
    @Transaction
    open suspend fun activate(pid: Long) {
        deleteActive(pid)
        setActive(pid)
    }

    @Query(
        """SELECT c.*, (f.channelKey IS NOT NULL) AS isFavorite FROM channels c
           LEFT JOIN favorites f ON f.channelKey = c.channelKey
           WHERE c.active = 1
             AND (:allGroups = 1 OR c.groupTitle IN (:groups))
             AND (:favOnly = 0 OR f.channelKey IS NOT NULL)
             AND (:query = '' OR c.name LIKE '%' || :query || '%')
           ORDER BY CASE WHEN :alpha = 1 THEN c.name END COLLATE NOCASE, c.id
           LIMIT :limit"""
    )
    abstract fun observe(
        allGroups: Int, groups: List<String>, favOnly: Int, query: String, alpha: Int, limit: Int
    ): Flow<List<ChannelItem>>

    @Query("SELECT groupTitle FROM channels WHERE active = 1 GROUP BY groupTitle ORDER BY groupTitle COLLATE NOCASE")
    abstract fun observeGroups(): Flow<List<String>>

    @Query("SELECT COUNT(*) FROM channels WHERE active = 1")
    abstract fun observeCount(): Flow<Int>

    @Query(
        """SELECT c.*, 1 AS isFavorite FROM favorites f
           JOIN channels c ON c.channelKey = f.channelKey AND c.active = 1
           GROUP BY c.channelKey ORDER BY f.addedAt DESC LIMIT :n"""
    )
    abstract fun observeFavorites(n: Int): Flow<List<ChannelItem>>

    @Query(
        """SELECT c.*, EXISTS(SELECT 1 FROM favorites WHERE channelKey = c.channelKey) AS isFavorite
           FROM history h JOIN channels c ON c.channelKey = h.channelKey AND c.active = 1
           GROUP BY c.channelKey ORDER BY h.lastPlayedAt DESC LIMIT :n"""
    )
    abstract fun observeRecents(n: Int): Flow<List<ChannelItem>>

    @Query("SELECT * FROM channels WHERE channelKey = :key AND active = 1 LIMIT 1")
    abstract suspend fun byKey(key: String): ChannelEntity?

    @Query("SELECT * FROM channels WHERE active = 1 ORDER BY name COLLATE NOCASE LIMIT :n")
    abstract suspend fun firstChannels(n: Int): List<ChannelEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun addFavorite(f: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE channelKey = :key")
    abstract suspend fun removeFavorite(key: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE channelKey = :key)")
    abstract fun observeIsFavorite(key: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun touchHistory(h: HistoryEntity)

    @Query("DELETE FROM history")
    abstract suspend fun clearHistory()

    @Query("DELETE FROM favorites")
    abstract suspend fun clearFavorites()

    @Query("DELETE FROM favorites WHERE channelKey LIKE :prefix || '%'")
    abstract suspend fun deleteFavoritesWithPrefix(prefix: String)

    @Query("DELETE FROM history WHERE channelKey LIKE :prefix || '%'")
    abstract suspend fun deleteHistoryWithPrefix(prefix: String)
}
