package com.novatv.app

import android.app.Application
import com.novatv.app.data.db.NovaDatabase
import com.novatv.app.data.repo.NovaRepository
import com.novatv.app.data.settings.SettingsStore

class NovaApp : Application() {
    val database: NovaDatabase by lazy { NovaDatabase.build(this) }
    val repository: NovaRepository by lazy { NovaRepository(this, database) }
    val settings: SettingsStore by lazy { SettingsStore(this) }
}
