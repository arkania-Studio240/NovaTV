package com.novatv.app.security

import java.net.URI

object LogSanitizer {
    /** Devuelve solo esquema y host. Nunca usuario, contraseña, ruta ni query. */
    fun redact(url: String): String = try {
        val u = URI(url.trim())
        if (u.scheme != null && u.host != null) "${u.scheme}://${u.host}/…" else "url-oculta"
    } catch (e: Exception) {
        "url-oculta"
    }
}
