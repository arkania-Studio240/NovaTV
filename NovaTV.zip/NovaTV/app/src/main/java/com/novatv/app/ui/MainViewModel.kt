package com.novatv.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.novatv.app.NovaApp
import com.novatv.app.data.db.ChannelEntity
import com.novatv.app.data.db.ChannelItem
import com.novatv.app.data.db.FavoriteEntity
import com.novatv.app.data.db.HistoryEntity
import com.novatv.app.data.db.PlaylistEntity
import com.novatv.app.data.repo.ImportException
import com.novatv.app.data.repo.ImportProgress
import com.novatv.app.data.repo.RefreshResult
import com.novatv.app.data.settings.AppSettings
import com.novatv.app.work.RefreshScheduler
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.Normalizer

data class Category(val label: String, val groups: List<String>, val thematic: Boolean)

data class ChannelFilter(
    val category: Category? = null,
    val query: String = "",
    val favOnly: Boolean = false,
    val alpha: Boolean = true,
    val limit: Int = 300
)

sealed interface ImportUi {
    data object Idle : ImportUi
    data class Running(val name: String, val channels: Int, val fraction: Float?) : ImportUi
    data class Message(val text: String, val isError: Boolean) : ImportUi
}

private val THEMES = listOf(
    "Deportes" to listOf("deport", "sport", "futbol", "football", "soccer", "nba", "liga"),
    "Noticias" to listOf("notici", "news"),
    "Películas" to listOf("pelicula", "movie", "cine", "film"),
    "Series" to listOf("serie"),
    "Infantiles" to listOf("infantil", "kids", "ninos", "cartoon", "dibujos"),
    "Música" to listOf("music", "musica")
)

private fun String.plain(): String =
    Normalizer.normalize(lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

/** Las categorías temáticas solo aparecen si algún group-title las respalda. */
fun buildCategories(groups: List<String>): List<Category> {
    val plainGroups = groups.map { it to it.plain() }
    val thematic = THEMES.mapNotNull { (label, keys) ->
        val matched = plainGroups.filter { (_, p) -> keys.any { p.contains(it) } }.map { it.first }
        if (matched.isEmpty()) null else Category(label, matched, true)
    }
    return thematic + groups.map { Category(it, listOf(it), false) }
}

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val nova = app as NovaApp
    private val repo = nova.repository
    private val dao = nova.database.channels()
    private val store = nova.settings

    val settings: StateFlow<AppSettings> =
        store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val playlists: StateFlow<List<PlaylistEntity>> =
        repo.playlists.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalChannels: StateFlow<Int> =
        dao.observeCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val categories: StateFlow<List<Category>> =
        dao.observeGroups().map { buildCategories(it) }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<List<ChannelItem>> =
        dao.observeFavorites(20).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recents: StateFlow<List<ChannelItem>> =
        dao.observeRecents(16).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ---- Filtro de canales (búsqueda instantánea + carga incremental) ----
    private val _filter = MutableStateFlow(ChannelFilter())
    val filter: StateFlow<ChannelFilter> = _filter.asStateFlow()

    val channels: StateFlow<List<ChannelItem>> = _filter
        .debounce(150)
        .distinctUntilChanged()
        .flatMapLatest { f ->
            dao.observe(
                allGroups = if (f.category == null) 1 else 0,
                groups = f.category?.groups ?: emptyList(),
                favOnly = if (f.favOnly) 1 else 0,
                query = f.query.trim(),
                alpha = if (f.alpha) 1 else 0,
                limit = f.limit
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setQuery(q: String) = _filter.update { it.copy(query = q, limit = PAGE) }
    fun setCategory(c: Category?) = _filter.update { it.copy(category = c, limit = PAGE) }
    fun toggleFavOnly() = _filter.update { it.copy(favOnly = !it.favOnly, limit = PAGE) }
    fun toggleAlpha() = _filter.update { it.copy(alpha = !it.alpha, limit = PAGE) }
    fun loadMore() = _filter.update { it.copy(limit = it.limit + PAGE) }

    private inline fun MutableStateFlow<ChannelFilter>.update(f: (ChannelFilter) -> ChannelFilter) {
        value = f(value)
    }

    fun toggleFavorite(item: ChannelItem) {
        viewModelScope.launch {
            if (item.isFavorite) dao.removeFavorite(item.channel.channelKey)
            else dao.addFavorite(FavoriteEntity(item.channel.channelKey, System.currentTimeMillis()))
        }
    }

    // ---- Reproducción ----
    val queue = MutableStateFlow<List<ChannelEntity>>(emptyList())
    val currentKey = MutableStateFlow<String?>(null)

    val current: StateFlow<ChannelEntity?> = combine(queue, currentKey) { q, k ->
        if (k == null) null else q.firstOrNull { it.channelKey == k }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val currentIsFavorite: StateFlow<Boolean> = currentKey
        .flatMapLatest { k -> if (k == null) flowOf(false) else dao.observeIsFavorite(k) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    fun openChannel(item: ChannelItem, list: List<ChannelItem>) {
        queue.value = list.map { it.channel }
        select(item.channel.channelKey)
    }

    fun openByKey(key: String) {
        queue.value = emptyList()
        select(key)
    }

    private fun select(key: String) {
        currentKey.value = key
        viewModelScope.launch {
            store.setLast(key)
            dao.touchHistory(HistoryEntity(key, System.currentTimeMillis()))
        }
    }

    /** Si se entra sin lista (reanudar último canal), se arma una cola con los canales disponibles. */
    suspend fun ensureQueue(key: String) {
        if (queue.value.any { it.channelKey == key }) return
        val list = dao.firstChannels(5000).toMutableList()
        if (list.none { it.channelKey == key }) dao.byKey(key)?.let { list.add(0, it) }
        queue.value = list
    }

    fun step(delta: Int) {
        val q = queue.value
        if (q.isEmpty()) return
        val i = q.indexOfFirst { it.channelKey == currentKey.value }
        if (i < 0) return
        select(q[(i + delta + q.size) % q.size].channelKey)
    }

    fun toggleCurrentFavorite() {
        val k = currentKey.value ?: return
        viewModelScope.launch {
            if (currentIsFavorite.value) dao.removeFavorite(k)
            else dao.addFavorite(FavoriteEntity(k, System.currentTimeMillis()))
        }
    }

    suspend fun lastPlayableKey(): String? {
        val k = store.flow.first().lastChannelKey ?: return null
        return if (dao.byKey(k) != null) k else null
    }

    suspend fun readSettings(): AppSettings = store.flow.first()

    // ---- Listas ----
    private val _import = MutableStateFlow<ImportUi>(ImportUi.Idle)
    val importState: StateFlow<ImportUi> = _import.asStateFlow()
    private var importJob: Job? = null

    private fun launchImport(label: String, block: suspend ((ImportProgress) -> Unit) -> RefreshResult) {
        if (importJob?.isActive == true) {
            _import.value = ImportUi.Message("Ya hay una importación en curso.", true)
            return
        }
        _import.value = ImportUi.Running(label, 0, null)
        importJob = viewModelScope.launch {
            try {
                val r = block { p -> _import.value = ImportUi.Running(p.name, p.channels, p.fraction) }
                _import.value = ImportUi.Message(
                    if (r.unchanged) "La lista ya estaba actualizada." else "Lista importada: ${r.count} canales.",
                    false
                )
            } catch (e: CancellationException) {
                _import.value = ImportUi.Message("Importación cancelada.", false)
                throw e
            } catch (e: ImportException) {
                _import.value = ImportUi.Message(e.message ?: "Error al importar.", true)
            } catch (e: Exception) {
                _import.value = ImportUi.Message("Error inesperado al importar.", true)
            }
        }
    }

    private fun validUrl(u: String): Boolean {
        val ok = u.startsWith("http://", true) || u.startsWith("https://", true)
        if (!ok) _import.value = ImportUi.Message("La dirección debe empezar por http:// o https://", true)
        return ok
    }

    fun addUrl(name: String, url: String) {
        val u = url.trim()
        if (!validUrl(u)) return
        launchImport(name) { report ->
            val id = repo.addUrl(name, u)
            repo.refresh(id, true, report)
        }
    }

    fun addFile(uri: Uri) = launchImport("Archivo") { report ->
        val id = repo.addFile(uri)
        repo.refresh(id, true, report)
    }

    fun refresh(p: PlaylistEntity) = launchImport(p.name) { report -> repo.refresh(p.id, true, report) }

    fun updatePlaylist(p: PlaylistEntity, name: String, newUrl: String?) {
        if (newUrl.isNullOrBlank()) {
            viewModelScope.launch { repo.updatePlaylist(p.id, name, null) }
        } else {
            val u = newUrl.trim()
            if (!validUrl(u)) return
            launchImport(name) { report ->
                repo.updatePlaylist(p.id, name, u)
                repo.refresh(p.id, true, report)
            }
        }
    }

    fun deletePlaylist(p: PlaylistEntity) {
        viewModelScope.launch {
            repo.deletePlaylist(p.id)
            if (queue.value.any { it.playlistId == p.id }) queue.value = emptyList()
        }
    }

    fun cancelImport() { importJob?.cancel() }
    fun dismissImport() { if (importJob?.isActive != true) _import.value = ImportUi.Idle }

    // ---- Ajustes ----
    fun setAutoUpdate(v: Boolean) = viewModelScope.launch {
        store.setAutoUpdate(v)
        RefreshScheduler.apply(getApplication(), v)
    }
    fun setResumeLast(v: Boolean) = viewModelScope.launch { store.setResumeLast(v) }
    fun setPlayOnStart(v: Boolean) = viewModelScope.launch { store.setPlayOnStart(v) }
    fun setTheme(v: String) = viewModelScope.launch { store.setTheme(v) }

    fun clearHistory() = viewModelScope.launch {
        repo.clearHistory()
        store.setLast(null)
    }

    fun deleteEverything() = viewModelScope.launch {
        importJob?.cancel()
        repo.deleteAll()
        store.setLast(null)
        queue.value = emptyList()
        currentKey.value = null
        _import.value = ImportUi.Idle
    }

    private companion object { const val PAGE = 300 }
}
