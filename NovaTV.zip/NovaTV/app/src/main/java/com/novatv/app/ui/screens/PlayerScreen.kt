@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.novatv.app.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.novatv.app.ui.MainViewModel
import com.novatv.app.ui.components.ChannelLogo
import com.novatv.app.ui.components.focusBorder
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

private const val MAX_RETRIES = 3

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

private fun describe(e: PlaybackException): String = when (e.errorCode) {
    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
        "No se pudo conectar con el canal. Revisa tu conexión; el servidor puede estar caído."
    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
        "El servidor rechazó la petición. El canal puede estar caído o requerir autorización."
    PlaybackException.ERROR_CODE_IO_CLEARTEXT_NOT_PERMITTED ->
        "Android bloqueó una conexión sin cifrar (http) para este canal."
    PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
    PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
    PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ->
        "El formato de este canal no es válido o no es compatible."
    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
    PlaybackException.ERROR_CODE_DECODING_FAILED,
    PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ->
        "Este dispositivo no puede decodificar el vídeo o el audio del canal."
    else -> "No se pudo reproducir el canal."
}

@Composable
fun PlayerScreen(vm: MainViewModel, isTv: Boolean, onExit: () -> Unit) {
    val ctx = LocalContext.current
    val activity = remember(ctx) { ctx.findActivity() }
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    val currentKey by vm.currentKey.collectAsStateWithLifecycle()
    val current by vm.current.collectAsStateWithLifecycle()
    val isFav by vm.currentIsFavorite.collectAsStateWithLifecycle()

    var overlay by remember { mutableStateOf(false) }
    var showTracks by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(true) }
    var playing by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var retries by remember { mutableIntStateOf(0) }
    var tracks by remember { mutableStateOf(Tracks.EMPTY) }
    var interaction by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf(true) }
    val rootFocus = remember { FocusRequester() }

    LaunchedEffect(currentKey) { currentKey?.let { vm.ensureQueue(it) } }

    val exo = remember {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("NovaTV/1.0")
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setAllowCrossProtocolRedirects(true)
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()
            .apply { playWhenReady = true }
    }

    val listener = remember {
        object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) {
                    retries = 0
                    errorMsg = null
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onTracksChanged(t: Tracks) { tracks = t }

            override fun onPlayerError(error: PlaybackException) {
                buffering = false
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    exo.seekToDefaultPosition()
                    exo.prepare()
                    return
                }
                if (retries < MAX_RETRIES) {
                    retries += 1
                    val attempt = retries
                    scope.launch {
                        delay(1500L * attempt)
                        exo.prepare()
                    }
                } else {
                    errorMsg = describe(error)
                    overlay = true
                }
            }
        }
    }

    DisposableEffect(exo) {
        exo.addListener(listener)
        onDispose {
            exo.removeListener(listener)
            exo.release() // liberación correcta al cerrar la pantalla
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, exo) {
        val obs = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> exo.pause()
                Lifecycle.Event.ON_START -> exo.play()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // Pantalla completa; en móvil se pasa a horizontal al entrar.
    DisposableEffect(Unit) {
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        if (!isTv) activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            if (!isTv) activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Cada vez que cambia el canal se carga el nuevo stream.
    LaunchedEffect(current?.channelKey) {
        val ch = current ?: return@LaunchedEffect
        errorMsg = null
        retries = 0
        buffering = true
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().clearOverrides().build()
        exo.setMediaItem(MediaItem.fromUri(ch.url))
        exo.prepare()
        exo.play()
        info = true
        delay(3500)
        info = false
    }

    // Devuelve el foco al contenedor cuando no hay controles visibles (D-pad).
    LaunchedEffect(overlay, showTracks) {
        if (!overlay && !showTracks) runCatching { rootFocus.requestFocus() }
    }
    // Los controles se ocultan solos.
    LaunchedEffect(overlay, interaction, errorMsg, showTracks) {
        if (overlay && errorMsg == null && !showTracks) {
            delay(6000)
            overlay = false
        }
    }

    val audio = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    fun volume(up: Boolean) {
        audio.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
    }

    BackHandler {
        when {
            showTracks -> showTracks = false
            overlay -> overlay = false
            else -> onExit()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onPreviewKeyEvent { ev ->
                interaction += 1
                if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                if (overlay || showTracks) return@onPreviewKeyEvent false
                when (ev.key) {
                    Key.DirectionUp, Key.ChannelDown -> { vm.step(-1); true }
                    Key.DirectionDown, Key.ChannelUp -> { vm.step(1); true }
                    Key.DirectionLeft -> { volume(false); true }
                    Key.DirectionRight -> { volume(true); true }
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { overlay = true; true }
                    else -> false
                }
            }
            .focusRequester(rootFocus)
            .focusable()
    ) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    keepScreenOn = true
                    isFocusable = false
                    descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
                    player = exo
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) { detectTapGestures { overlay = !overlay } }
        )

        val err = errorMsg
        if (err != null) {
            Text(
                err, color = Color.White, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(32.dp),
                style = MaterialTheme.typography.titleMedium
            )
        } else if (buffering) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
        }

        // Información breve del canal (no tapa el vídeo).
        AnimatedVisibility(
            visible = info && !overlay && current != null,
            modifier = Modifier.align(Alignment.TopStart).padding(20.dp),
            enter = fadeIn(), exit = fadeOut()
        ) {
            current?.let { ch ->
                Row(
                    Modifier.background(Color(0xB3000000), RoundedCornerShape(12.dp)).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ChannelLogo(ch.name, ch.logo, Modifier.size(40.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(ch.name, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (retries > 0 && errorMsg == null) "Reintentando ($retries/$MAX_RETRIES)…" else ch.groupTitle,
                            color = Color(0xFFCBD5E8), style = MaterialTheme.typography.bodySmall, maxLines = 1
                        )
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = overlay,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(), exit = fadeOut()
        ) {
            val firstFocus = remember { FocusRequester() }
            LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                current?.let { ch ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ChannelLogo(ch.name, ch.logo, Modifier.size(52.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(ch.name, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(ch.groupTitle, color = Color(0xFFCBD5E8), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        }
                    }
                    Spacer(Modifier.size(12.dp))
                }
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CtrlButton(rememberVectorPainter(Icons.Default.KeyboardArrowUp), "Canal anterior", Modifier.focusRequester(firstFocus)) { vm.step(-1) }
                    if (exo.isCommandAvailable(Player.COMMAND_PLAY_PAUSE)) {
                        CtrlButton(
                            if (playing) painterResource(com.novatv.app.R.drawable.ic_pause) else rememberVectorPainter(Icons.Default.PlayArrow),
                            if (playing) "Pausar" else "Reanudar"
                        ) { if (exo.isPlaying) exo.pause() else exo.play() }
                    }
                    CtrlButton(rememberVectorPainter(Icons.Default.KeyboardArrowDown), "Canal siguiente") { vm.step(1) }
                    CtrlButton(painterResource(com.novatv.app.R.drawable.ic_volume_down), "Bajar volumen") { volume(false) }
                    CtrlButton(painterResource(com.novatv.app.R.drawable.ic_volume_up), "Subir volumen") { volume(true) }
                    CtrlButton(painterResource(com.novatv.app.R.drawable.ic_tracks), "Audio y subtítulos") {
                        overlay = false
                        showTracks = true
                    }
                    CtrlButton(
                        rememberVectorPainter(if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder),
                        if (isFav) "Quitar de favoritos" else "Añadir a favoritos"
                    ) { vm.toggleCurrentFavorite() }
                    if (errorMsg != null) {
                        CtrlButton(rememberVectorPainter(Icons.Default.Refresh), "Reintentar") {
                            errorMsg = null; retries = 0; buffering = true
                            exo.prepare(); exo.play()
                        }
                    }
                    if (!isTv) {
                        CtrlButton(painterResource(com.novatv.app.R.drawable.ic_rotate), "Girar pantalla") {
                            activity?.requestedOrientation =
                                if (isLandscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        }
                    }
                    CtrlButton(rememberVectorPainter(Icons.Default.Close), "Salir del reproductor") { onExit() }
                }
            }
        }
    }

    if (showTracks) TracksDialog(exo, tracks) { showTracks = false }
}

@Composable
private fun CtrlButton(icon: Painter, description: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = modifier.size(52.dp).focusBorder(CircleShape)) {
        Icon(icon, contentDescription = description, tint = Color.White)
    }
}

private fun trackLabel(f: Format, index: Int): String =
    f.label ?: f.language?.let { Locale(it).displayLanguage.ifBlank { it } } ?: "Pista ${index + 1}"

@Composable
private fun TracksDialog(player: Player, tracks: Tracks, onDismiss: () -> Unit) {
    val audio = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
    val text = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }

    fun select(group: Tracks.Group, index: Int) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(group.type, false)
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, index))
            .build()
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Audio y subtítulos") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Audio", fontWeight = FontWeight.Bold)
                if (audio.isEmpty()) Text("Este canal no ofrece pistas de audio alternativas.")
                audio.forEach { g ->
                    for (i in 0 until g.length) {
                        if (!g.isTrackSupported(i)) continue
                        TrackRow(trackLabel(g.getTrackFormat(i), i), g.isTrackSelected(i)) { select(g, i) }
                    }
                }
                Spacer(Modifier.size(12.dp))
                Text("Subtítulos", fontWeight = FontWeight.Bold)
                if (text.isEmpty()) Text("Este canal no tiene subtítulos disponibles.")
                else {
                    TrackRow("Desactivados", text.none { it.isSelected }) {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                        onDismiss()
                    }
                    text.forEach { g ->
                        for (i in 0 until g.length) {
                            if (!g.isTrackSupported(i)) continue
                            TrackRow(trackLabel(g.getTrackFormat(i), i), g.isTrackSelected(i)) { select(g, i) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss, modifier = Modifier.focusBorder()) { Text("Cerrar") } }
    )
}

@Composable
private fun TrackRow(label: String, selected: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth().focusBorder()) {
        Text(
            (if (selected) "● " else "○ ") + label,
            Modifier.fillMaxWidth(), textAlign = TextAlign.Start
        )
    }
}
