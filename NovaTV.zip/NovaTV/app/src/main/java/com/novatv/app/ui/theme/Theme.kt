package com.novatv.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp

val LocalIsTv = staticCompositionLocalOf { false }

private val Accent = Color(0xFF4C8DFF)

@Composable
fun NovaTheme(themeKey: String, isTv: Boolean, content: @Composable () -> Unit) {
    val scheme = when (themeKey) {
        "light" -> lightColorScheme(
            primary = Color(0xFF1F5FD6), background = Color(0xFFF4F6FB), surface = Color.White,
            surfaceVariant = Color(0xFFE3E8F3), onBackground = Color(0xFF0B1220),
            onSurface = Color(0xFF0B1220), onSurfaceVariant = Color(0xFF51607F)
        )
        "black" -> darkColorScheme(
            primary = Accent, background = Color.Black, surface = Color(0xFF0A0A10),
            surfaceVariant = Color(0xFF16161F), onBackground = Color(0xFFEAF0FF),
            onSurface = Color(0xFFEAF0FF), onSurfaceVariant = Color(0xFF9AA3B8)
        )
        else -> darkColorScheme(
            primary = Accent, background = Color(0xFF070B14), surface = Color(0xFF0E1526),
            surfaceVariant = Color(0xFF16203A), onBackground = Color(0xFFEAF0FF),
            onSurface = Color(0xFFEAF0FF), onSurfaceVariant = Color(0xFF9AA8C7)
        )
    }
    val base = LocalDensity.current
    // En TV todo se amplía un poco para que sea legible a distancia.
    val density = if (isTv) Density(base.density * 1.25f, base.fontScale) else base
    CompositionLocalProvider(LocalIsTv provides isTv, LocalDensity provides density) {
        MaterialTheme(
            colorScheme = scheme,
            shapes = Shapes(
                small = RoundedCornerShape(8.dp),
                medium = RoundedCornerShape(12.dp),
                large = RoundedCornerShape(16.dp)
            ),
            content = content
        )
    }
}
